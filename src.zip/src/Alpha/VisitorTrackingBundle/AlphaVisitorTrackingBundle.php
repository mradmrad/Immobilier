<?php

namespace Alpha\VisitorTrackingBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AlphaVisitorTrackingBundle extends Bundle
{
}
