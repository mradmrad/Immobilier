Visitor Tracking Bundle
=======================

A Symfony2 bundle to track the requests.