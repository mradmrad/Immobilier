<?php

namespace SBC\AddressBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AddressBundle extends Bundle
{
}
