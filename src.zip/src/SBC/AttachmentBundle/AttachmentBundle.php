<?php

namespace SBC\AttachmentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AttachmentBundle extends Bundle
{
}
