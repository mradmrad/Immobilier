<?php

namespace SBC\BienBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BienBundle extends Bundle
{
}
