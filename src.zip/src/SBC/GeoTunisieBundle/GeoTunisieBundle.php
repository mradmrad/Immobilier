<?php

namespace SBC\GeoTunisieBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GeoTunisieBundle extends Bundle
{
}
