<?php

namespace SBC\ImmobilierBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ImmobilierBundle extends Bundle
{
}
